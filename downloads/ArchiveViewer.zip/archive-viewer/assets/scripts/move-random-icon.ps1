# move-random-icon.ps1
#
# Picks one random icon on the Windows desktop and moves it to a random
# position within the primary monitor's work area.
#
# This uses the same public Win32 messaging interface Explorer itself
# uses to lay out desktop icons (the desktop is just a SysListView32
# control under Progman -> SHELLDLL_DefView). No files are moved, renamed,
# or touched - only the on-screen icon position changes, and it's fully
# reversible: right-click the desktop -> View -> "Auto arrange icons" (or
# just drag icons back) restores a normal layout at any time.

Add-Type -AssemblyName System.Windows.Forms

Add-Type @"
using System;
using System.Runtime.InteropServices;

public class DesktopIconMover {
    [DllImport("user32.dll", SetLastError = true)]
    public static extern IntPtr FindWindow(string lpClassName, string lpWindowName);

    [DllImport("user32.dll", SetLastError = true)]
    public static extern IntPtr FindWindowEx(IntPtr hwndParent, IntPtr hwndChildAfter, string lpszClass, string lpszWindow);

    [DllImport("user32.dll")]
    public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);

    const int LVM_GETITEMCOUNT = 0x1004;
    const int LVM_SETITEMPOSITION = 0x100F;

    public static IntPtr GetDesktopListView() {
        IntPtr progman = FindWindow("Progman", null);
        IntPtr defView = FindWindowEx(progman, IntPtr.Zero, "SHELLDLL_DefView", null);
        if (defView == IntPtr.Zero) {
            // Some Windows versions/configurations host the desktop under a
            // separate WorkerW window instead of directly under Progman.
            // Not handled here for simplicity - script just no-ops if so.
            return IntPtr.Zero;
        }
        return FindWindowEx(defView, IntPtr.Zero, "SysListView32", "FolderView");
    }

    public static int GetItemCount(IntPtr listView) {
        return SendMessage(listView, LVM_GETITEMCOUNT, 0, 0);
    }

    public static void MoveIcon(IntPtr listView, int index, int x, int y) {
        int lParam = (y << 16) | (x & 0xFFFF);
        SendMessage(listView, LVM_SETITEMPOSITION, index, lParam);
    }
}
"@

$listView = [DesktopIconMover]::GetDesktopListView()
if ($listView -eq [IntPtr]::Zero) {
    Write-Output "Desktop list view not found - skipping."
    exit 0
}

$count = [DesktopIconMover]::GetItemCount($listView)
if ($count -le 0) {
    Write-Output "No desktop icons found - skipping."
    exit 0
}

$index = Get-Random -Minimum 0 -Maximum $count

$workArea = [System.Windows.Forms.Screen]::PrimaryScreen.WorkingArea
$margin = 80
$maxX = [Math]::Max($margin + 1, $workArea.Width - $margin)
$maxY = [Math]::Max($margin + 1, $workArea.Height - $margin)
$x = Get-Random -Minimum $margin -Maximum $maxX
$y = Get-Random -Minimum $margin -Maximum $maxY

[DesktopIconMover]::MoveIcon($listView, $index, $x, $y)
Write-Output "Moved desktop icon index $index to ($x, $y)"
