ARCHIVE VIEWER
==============
build 0.1  —  internal use

I built this because the tapes stopped playing on anything else.

Every deck I own reads them for a second and then spits them out. The DVD
recorder (the Sony, the DCR-DVD203 I shot most of them on) shows the index
and then locks up. So I wrote my own reader. It ignores the disc's own
header and pulls the video out the back way, into a format only this
program knows how to open. That's the .arcv files in assets/videos. If you
have a raw clip you want to bring in, run it through tools/encode.js first
and it shows up in the list on its own.

Everything in the list is dated 2018. That's when I last had them open.
I didn't touch the dates after that. I don't know why they still say 2018.

Notes on using it
-----------------
- Pick a tape on the left. It loads and plays.
- REVERSE runs it backward. This matters. Some of the tapes have things in
  them that you only catch going the other way. Slow it down too (0.5x,
  0.25x). Take your time.
- The picture warbles sometimes. The audio bends up or down for a second.
  I thought it was the encoder at first and rewrote it twice. It isn't the
  encoder. It does it on the original discs too.
- Leave it open and you'll hear it running. A hum, and a click now and
  then, like a head seating. That's just the program idling. I find it
  easier to work with the sound on than off, which I can't explain.

Adding a tape
-------------
The list starts with the slots empty — NO SIGNAL. As I recover each tape I
put the file out where you can get it. When you have one, bring it in:
IMPORT TAPE, bottom left, or just drag the file onto the window. It takes a
second to read it in and then it's yours to watch. They go in in order. You
can't skip ahead to a tape I haven't put out yet — there's nothing there to
load.

Watch all of them
-----------------
When you've been through every tape, close the program. Don't just leave it
open — close it, all the way, and open it again.

There's one more after that. It wasn't in the original set. I didn't
encode it. It shows up at the bottom of the list on its own once you've
seen the rest, and I would rather you saw the rest first.

If it comes up as SIGNAL LOST for you, that's as far as I got. It reads as
present but I can't get a clean picture off it. If you manage to, I'd want
to know what's on it.

The desktop
-----------
It sits in the tray and keeps working while you're doing other things. It
will make noise, and now and then it moves one of the icons on your
desktop. Just moves it — nothing is deleted, nothing is opened, and you can
put it back (right-click the desktop → View → Auto arrange). The longer you
leave it running, the more it does this. I noticed that late. I don't think
it started out that way.

You agreed to all of that the first time you opened it — it asked, plainly,
before it did anything. If you don't want it running in the background, say
no when it asks and it stays a plain viewer that quits when you close it.

Uninstalling
------------
There's an UNINSTALL button, top right. It'll ask you first. If you go
through with it —

I don't want to write down what it did on mine. It asked, I said yes, and
it did not uninstall. Every time I open it now it's not the same program.

Keep your originals somewhere else. Don't keep them only in here.

— D.
