const tapesEl = document.getElementById('tapes');
const player = document.getElementById('player');
const idleMessage = document.getElementById('idle-message');
const statusBar = document.getElementById('status-bar');
const staticOverlay = document.getElementById('static-overlay');
const clockEl = document.getElementById('clock');
const ambientAudio = document.getElementById('ambient-audio');
const lostSignal = document.getElementById('lost-signal');
const lostSignalText = document.getElementById('lost-signal-text');

const metaCameraEl = document.getElementById('meta-camera');
const metaFormatEl = document.getElementById('meta-format');
const metaLastOpenedEl = document.getElementById('meta-last-opened');
const metaSourceEl = document.getElementById('meta-source');
const metaSourceWrap = document.getElementById('meta-source-wrap');

const btnImport = document.getElementById('btn-import');
const dropVeil = document.getElementById('drop-veil');

const tapeMetaById = {};
let currentTapeId = null;

function updateClock() {
  clockEl.textContent = new Date().toTimeString().split(' ')[0];
}
setInterval(updateClock, 1000);
updateClock();

function setMeta(meta) {
  if (!meta) {
    metaCameraEl.textContent = '—';
    metaFormatEl.textContent = '—';
    metaLastOpenedEl.textContent = '—';
    metaSourceWrap.style.display = 'none';
    return;
  }
  metaCameraEl.textContent = meta.camera || '—';
  metaFormatEl.textContent = meta.format || '—';
  metaLastOpenedEl.textContent = meta.lastOpened || '—';
  if (meta.source) {
    metaSourceEl.textContent = meta.source;
    metaSourceWrap.style.display = '';
  } else {
    metaSourceWrap.style.display = 'none';
  }
}

// (Re)build the tape list from the current archive state.
async function buildList() {
  const videos = await window.archive.listVideos();
  tapesEl.innerHTML = '';
  for (const k of Object.keys(tapeMetaById)) delete tapeMetaById[k];

  // Only ever show tapes that actually exist. Empty (locked) slots are never
  // rendered - the list starts blank and grows as the player imports.
  const visible = videos.filter((v) => !v.locked);

  if (visible.length === 0) {
    tapesEl.innerHTML = '<div class="tape-item" style="opacity:.5;cursor:default">NO TAPES YET</div>';
    statusBar.textContent = 'ARCHIVE EMPTY — import a tape to begin';
    return;
  }

  visible.forEach((v) => {
    tapeMetaById[v.id] = v;
    const item = document.createElement('div');
    item.className = 'tape-item' + (v.mystery ? ' mystery' : '');
    item.textContent = v.label;
    item.addEventListener('click', () => playTape(v.id, item));
    tapesEl.appendChild(item);
  });
}

async function playTape(id, itemEl) {
  document.querySelectorAll('.tape-item').forEach((el) => el.classList.remove('active'));
  itemEl.classList.add('active');

  currentTapeId = id;
  setMeta(tapeMetaById[id]);

  stopReverse();
  idleMessage.style.display = 'none';
  lostSignal.classList.remove('visible');
  triggerStaticBurst();
  ensureAudio();

  statusBar.textContent = `LOADING: ${id} ...`;

  try {
    const dataUrl = await window.archive.loadVideo(id);

    if (!dataUrl) {
      player.pause();
      player.removeAttribute('src');
      player.load();
      idleSound.setPlaying(false);
      lostSignalText.textContent = 'SIGNAL LOST';
      lostSignal.classList.add('visible');
      statusBar.textContent = 'NO READABLE SIGNAL ON THIS TAPE';
      return;
    }

    player.src = dataUrl;
    player.playbackRate = currentSpeed;
    await player.play();
    idleSound.setPlaying(true);
    statusBar.textContent = `PLAYING: ${id}`;
  } catch (err) {
    statusBar.textContent = `ERROR DECODING TAPE: ${err.message}`;
  }
}

function triggerStaticBurst() {
  staticOverlay.classList.remove('burst');
  void staticOverlay.offsetWidth;
  staticOverlay.classList.add('burst');
}

// ---------- Import ----------

async function doImport(sourcePath) {
  statusBar.textContent = 'IMPORTING TAPE...';
  triggerStaticBurst();
  const res = await window.archive.importTape(sourcePath);
  if (res && res.ok) {
    statusBar.textContent = `LOGGED: ${res.label}`;
    await buildList();
  } else if (res && res.canceled) {
    statusBar.textContent = currentTapeId ? `PLAYING: ${currentTapeId}` : 'NO SIGNAL';
  } else {
    statusBar.textContent = (res && res.error) || 'IMPORT FAILED';
  }
}

btnImport.addEventListener('click', () => {
  ensureAudio();
  doImport(); // no path -> main opens the native file picker
});

// Drag-and-drop anywhere in the window.
let dragDepth = 0;
window.addEventListener('dragenter', (e) => {
  e.preventDefault();
  dragDepth++;
  dropVeil.classList.add('visible');
});
window.addEventListener('dragover', (e) => { e.preventDefault(); });
window.addEventListener('dragleave', (e) => {
  e.preventDefault();
  dragDepth = Math.max(0, dragDepth - 1);
  if (dragDepth === 0) dropVeil.classList.remove('visible');
});
window.addEventListener('drop', (e) => {
  e.preventDefault();
  dragDepth = 0;
  dropVeil.classList.remove('visible');
  ensureAudio();
  const file = e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files[0];
  if (!file) return;
  const p = window.archive.getDroppedPath(file);
  if (p) doImport(p);
  else statusBar.textContent = 'COULD NOT READ DROPPED FILE';
});

// Mark a tape watched once it plays through to the end - what eventually
// unlocks the hidden "???" tape (revealed on next launch).
player.addEventListener('ended', () => {
  idleSound.setPlaying(false);
  if (currentTapeId) window.archive.markWatched(currentTapeId);
});
player.addEventListener('pause', () => idleSound.setPlaying(false));
player.addEventListener('play', () => idleSound.setPlaying(true));

// ---------- Reverse playback + slowdown ----------

const btnReverse = document.getElementById('btn-reverse');
const btnForward = document.getElementById('btn-forward');
const speedSelect = document.getElementById('speed-select');

let reverseTimer = null;
let currentSpeed = 1;

const REVERSE_STEP_SECONDS = 0.05;
const REVERSE_TICK_MS = 40;

function startReverse() {
  if (reverseTimer) return;
  player.pause();
  btnReverse.classList.add('active');
  btnForward.classList.remove('active');
  statusBar.textContent = 'PLAYING IN REVERSE';

  reverseTimer = setInterval(() => {
    const next = player.currentTime - REVERSE_STEP_SECONDS * currentSpeed;
    if (next <= 0) {
      player.currentTime = 0;
      stopReverse();
      statusBar.textContent = 'REACHED START OF TAPE';
      return;
    }
    player.currentTime = next;
  }, REVERSE_TICK_MS);
}

function stopReverse() {
  if (reverseTimer) {
    clearInterval(reverseTimer);
    reverseTimer = null;
  }
  btnReverse.classList.remove('active');
}

function resumeForward() {
  stopReverse();
  btnForward.classList.add('active');
  player.play().then(() => {
    statusBar.textContent = 'PLAYING';
  }).catch(() => {
    statusBar.textContent = 'PAUSED';
  });
  setTimeout(() => btnForward.classList.remove('active'), 200);
}

btnReverse.addEventListener('click', () => {
  if (reverseTimer) {
    stopReverse();
    statusBar.textContent = 'PAUSED (REVERSE)';
  } else {
    startReverse();
  }
});

btnForward.addEventListener('click', resumeForward);

speedSelect.addEventListener('change', () => {
  currentSpeed = parseFloat(speedSelect.value);
  player.playbackRate = currentSpeed;
});

// ---------- Tape warble (random audio pitch/speed glitch) ----------

const WARBLE_CHECK_MS = 4000;
const WARBLE_CHANCE = 0.28;

let warbleActive = false;

function maybeWarble() {
  if (warbleActive) return;
  if (reverseTimer) return;
  if (player.paused || player.ended) return;
  if (!player.src) return;
  if (Math.random() > WARBLE_CHANCE) return;

  warbleActive = true;
  const factor = 0.78 + Math.random() * 0.5;
  const duration = 80 + Math.random() * 200;
  const baseline = currentSpeed;

  player.playbackRate = baseline * factor;
  if (Math.random() < 0.6) triggerStaticBurst();

  setTimeout(() => {
    if (!reverseTimer) player.playbackRate = currentSpeed;
    warbleActive = false;
  }, duration);
}

setInterval(maybeWarble, WARBLE_CHECK_MS);

setInterval(() => {
  if (Math.random() < 0.15) triggerStaticBurst();
}, 8000);

// A random background sound file, chosen and pushed by the main process.
window.archive.onPlaySound((url) => {
  triggerStaticBurst();
  try {
    const a = new Audio(url);
    a.volume = 1.0;
    a.play().catch(() => {});
  } catch (e) { /* ignore */ }
});

// ---------- Procedural idle soundscape (Web Audio) ----------

const idleSound = (() => {
  let ctx = null;
  let humGain = null;
  let masterGain = null;
  let clickTimer = null;
  let started = false;
  let playing = false;

  const HUM_IDLE = 0.045;
  const HUM_DUCKED = 0.012;

  function start() {
    if (started) return;
    started = true;
    try {
      ctx = new (window.AudioContext || window.webkitAudioContext)();
    } catch (e) {
      return;
    }

    masterGain = ctx.createGain();
    masterGain.gain.value = 0.9;
    masterGain.connect(ctx.destination);

    humGain = ctx.createGain();
    humGain.gain.value = HUM_IDLE;
    const lp = ctx.createBiquadFilter();
    lp.type = 'lowpass';
    lp.frequency.value = 220;
    humGain.connect(lp);
    lp.connect(masterGain);

    const osc1 = ctx.createOscillator();
    osc1.type = 'triangle';
    osc1.frequency.value = 55;
    const osc2 = ctx.createOscillator();
    osc2.type = 'sine';
    osc2.frequency.value = 55.6;
    osc1.connect(humGain);
    osc2.connect(humGain);
    osc1.start();
    osc2.start();

    scheduleClick();
  }

  function scheduleClick() {
    const base = playing ? 9000 : 4500;
    const delay = base + Math.random() * base;
    clickTimer = setTimeout(() => {
      click();
      scheduleClick();
    }, delay);
  }

  function click() {
    if (!ctx) return;
    const now = ctx.currentTime;
    const dur = 0.03 + Math.random() * 0.05;
    const buffer = ctx.createBuffer(1, Math.ceil(ctx.sampleRate * dur), ctx.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < data.length; i++) {
      data[i] = (Math.random() * 2 - 1) * (1 - i / data.length);
    }
    const src = ctx.createBufferSource();
    src.buffer = buffer;
    const bp = ctx.createBiquadFilter();
    bp.type = 'bandpass';
    bp.frequency.value = 1400 + Math.random() * 2200;
    bp.Q.value = 6;
    const g = ctx.createGain();
    g.gain.value = playing ? 0.05 : 0.12;
    src.connect(bp);
    bp.connect(g);
    g.connect(masterGain);
    src.start(now);
    src.stop(now + dur);
  }

  function setPlaying(isPlaying) {
    playing = isPlaying;
    if (humGain && ctx) {
      const target = isPlaying ? HUM_DUCKED : HUM_IDLE;
      humGain.gain.setTargetAtTime(target, ctx.currentTime, 0.4);
    }
  }

  function resume() {
    if (ctx && ctx.state === 'suspended') ctx.resume().catch(() => {});
  }

  function suspend() {
    if (ctx && ctx.state === 'running') ctx.suspend().catch(() => {});
  }

  return {
    start() { start(); resume(); },
    setPlaying,
    suspend,
    resume,
    getContext: () => ctx,
    getMaster: () => masterGain,
  };
})();

function ensureAudio() { idleSound.start(); }
window.addEventListener('pointerdown', ensureAudio, { once: true });
window.addEventListener('keydown', ensureAudio, { once: true });

// When the window is closed-to-tray or minimized, go quiet: pause the tape and
// suspend the idle hum. (Background scares still fire from the main process.)
window.archive.onAppHidden(() => {
  try { player.pause(); } catch (e) {}
  idleSound.suspend();
});
window.archive.onAppShown(() => {
  idleSound.resume();
});

// ---------- Fake uninstall sequence ----------

const btnUninstall = document.getElementById('btn-uninstall');
const uninstallOverlay = document.getElementById('uninstall-overlay');
const uninstallFill = document.getElementById('uninstall-fill');
const uninstallPercent = document.getElementById('uninstall-percent');
const uninstallStatus = document.getElementById('uninstall-status');
const uninstallTitle = document.getElementById('uninstall-title');
const scareAudio = document.getElementById('scare-audio');

let uninstallRunning = false;

btnUninstall.addEventListener('click', async () => {
  if (uninstallRunning) return;
  ensureAudio();
  const confirmed = await window.archive.confirmUninstall();
  if (!confirmed) return;
  uninstallRunning = true;

  // Same uninstall sequence (progress bar + crash) either way. Only the
  // persisted end-state differs: finished everything -> "death" (a blank pink
  // window on every reopen, no repair); otherwise -> corrupted (the repair
  // flow on reopen).
  const prog = await window.archive.getProgress();
  runFakeUninstall(!!(prog && prog.completed));
});

function startUninstallAudio() {
  const ctx = idleSound.getContext();
  const master = idleSound.getMaster();
  if (!ctx || !master) return () => {};

  const now = ctx.currentTime;
  const osc = ctx.createOscillator();
  osc.type = 'sawtooth';
  const lp = ctx.createBiquadFilter();
  lp.type = 'lowpass';
  lp.frequency.value = 600;
  const g = ctx.createGain();
  g.gain.value = 0.0;
  osc.connect(lp);
  lp.connect(g);
  g.connect(master);

  osc.frequency.setValueAtTime(70, now);
  osc.frequency.linearRampToValueAtTime(150, now + 11);
  g.gain.linearRampToValueAtTime(0.05, now + 0.8);
  osc.start(now);

  let ticks = true;
  (function tick() {
    if (!ticks) return;
    const t = ctx.currentTime;
    const o = ctx.createOscillator();
    const tg = ctx.createGain();
    o.type = 'square';
    o.frequency.value = 900 + Math.random() * 600;
    tg.gain.value = 0.0;
    tg.gain.setValueAtTime(0.03, t);
    tg.gain.exponentialRampToValueAtTime(0.0001, t + 0.05);
    o.connect(tg);
    tg.connect(master);
    o.start(t);
    o.stop(t + 0.06);
    setTimeout(tick, 350 + Math.random() * 500);
  })();

  return function stop() {
    ticks = false;
    try {
      g.gain.setTargetAtTime(0.0001, ctx.currentTime, 0.1);
      osc.stop(ctx.currentTime + 0.3);
    } catch (e) { /* already stopped */ }
  };
}

async function runFakeUninstall(isDeath) {
  await wait(1100);

  uninstallOverlay.classList.add('visible');
  uninstallFill.style.width = '0%';
  uninstallStatus.textContent = 'Please wait while Windows configures Archive Viewer';
  uninstallPercent.textContent = 'Gathering required information...';
  uninstallTitle.textContent = 'Archive Viewer Setup';

  const stopAudio = startUninstallAudio();

  uninstallPercent.textContent = 'Removing Archive Viewer...';
  await animateProgress(0, 99, 7000);
  uninstallPercent.textContent = 'Finishing up...';
  await wait(1400);

  const breakDuration = 3200;
  await animateProgress(99, 134, breakDuration);

  await wait(500);

  stopAudio();
  try {
    scareAudio.currentTime = 0;
    scareAudio.play().catch(() => {});
  } catch (e) { /* missing asset in dev is fine */ }

  window.archive.triggerFakeUninstallClose(isDeath);
}

function animateProgress(from, to, durationMs) {
  return new Promise((resolve) => {
    const start = performance.now();
    function tick(now) {
      const t = Math.min((now - start) / durationMs, 1);
      const eased = 1 - Math.pow(1 - t, 3);
      const value = from + (to - from) * eased;
      uninstallFill.style.width = `${value}%`;
      if (to <= 100) uninstallPercent.textContent = `${Math.floor(value)}% complete`;
      if (t < 1) requestAnimationFrame(tick);
      else resolve();
    }
    requestAnimationFrame(tick);
  });
}

function wait(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

buildList();
