# Archive Viewer

A retro/analog-styled desktop video archive viewer, built as an Electron app,
intended as a component of an ARG.

## What this does

- Shows an honest, explicit consent dialog the first time it's launched,
  before any background behavior starts (see `main.js`, `showConsentDialog`).
- If the user consents, the app can minimize to the system tray and keep
  running after its window is closed.
- While running in the background (only with consent), it periodically
  plays a short sound and/or spawns a brief, transparent, click-through
  full-screen "glitch" overlay at random intervals (3–20 min). On Windows,
  it may also move a single random desktop icon to a new position (see
  below) — this is called out explicitly in the consent dialog. The
  desktop-icon effect **escalates**: the first move is scheduled far out
  (~8–14 min) so it's easy to miss, and each subsequent move comes sooner,
  down to a floor of ~40s so it never becomes spam. The count persists in
  `state.json`, so the escalation is remembered across sessions.
- The archive viewer itself plays videos that are packaged in a custom
  `.arcv` container format, which the app decodes on the fly. Plain `.mp4`
  files placed in `assets/videos/` will **not** show up — only `.arcv` files
  encoded via the included tool will.
- Consent is stored locally (`consent.json` in the Electron userData
  folder) so the dialog only appears once. Delete that file to re-trigger it
  during testing.

## New in this build

- **Tape metadata.** Each tape shows a last-opened date (all in 2018,
  deterministically derived from the filename so they're varied but stable)
  plus a default camera/format line (`Sony DCR-DVD203 (NTSC)` /
  `MiniDVD / NTSC 720x480`). Change the defaults via `DEFAULT_CAMERA` /
  `DEFAULT_FORMAT` in `main.js`; the date logic is `lastOpenedFor()`.
- **Tape warble.** During normal forward playback, playback rate randomly
  nudges up or down for a fraction of a second and snaps back — the audio
  bends in pitch like a real tape wow/flutter, paired with a small static
  tick. Skipped while reversing or paused. Tuning: `WARBLE_CHECK_MS` /
  `WARBLE_CHANCE` in `renderer.js`. (This shifts pitch *and* speed together,
  which is how tape actually warbles; a pitch-only shift would need a Web
  Audio pitch node.)
- **Import-based tape release (.arcv only).** The archive accepts only the
  five named, pre-encoded `.arcv` tapes in `config/expected-tapes.json`
  (`cabin`, `pink`, `picture`, `noise`, `mail`). Raw video is never imported —
  a file must be `.arcv`, pass the magic-header check, and be named to match a
  slot (`cabin.arcv` → the `cabin` slot). Anything else is rejected, and the
  same file can't be imported twice (content-hashed). The list **starts
  empty** and grows as each named tape is imported. See "Tape release model"
  below.
- **Two uninstall endings.** The uninstall sequence (bar + crash) is the same
  either way. Uninstall before finishing → reopen runs the "I want you to hurt"
  black/blue/repair flow. Uninstall *after* watching every tape → reopen is a
  blank **pink** window forever (title/taskbar `death` only, no repair). See
  "The Uninstall button" below.
- **Purple theme.** Accent recolored from amber to `#430130`. Because that
  value is very dark, `--accent-deep` (`#430130`) drives the CRT wash/borders
  and a lightened tint of the same hue (`--amber` in `style.css`) carries the
  text so it stays readable. Adjust either token in `:root`.
- **Hidden `???` tape.** Import **and** watch every expected tape to the end
  (tracked in `state.json`), then fully close and reopen the app — a red
  `???` entry appears at the bottom of the list. It plays a designated
  hidden asset if you drop one in (any `.arcv` whose name starts with `_`,
  in either the userData `videos/` folder or bundled `assets/videos/`, is
  excluded from the normal list and used as the `???` payload). With no such
  file, it shows a procedural `SIGNAL LOST` static screen as a hook for the
  next layer.
- **Procedural idle soundscape.** While the app is open it synthesizes a
  quiet machine presence — a low tape-transport hum plus sparse relay-style
  clicks — entirely in Web Audio (no asset to sound corny). It ducks while a
  tape is actually playing. Starts on the first click/keypress (browser
  autoplay rule). See the `idleSound` module in `renderer.js`.
- **Uninstall now asks first.** The UNINSTALL button is still always
  present, but it first shows a real native OS Yes/No confirmation
  (`confirm-uninstall` in `main.js`); only "Yes" starts the sequence. The
  progress window is restyled to read like a genuine Windows setup wizard
  (title bar, green fill, "Please wait while Windows configures…"), and has
  synthesized audio underneath it — a slow rising processing tone and faint
  ticks that cut out right at the crash handoff.
- **Startup safety fix.** If the app was set to launch at login and then hits
  the fake uninstall, the corrupted branch now calls
  `applyStartupSetting(false)` so the black-flash/crash loop no longer
  ambushes the user at every boot with no way to reach settings. It still
  plays whenever they open the app themselves.

State lives in `state.json` (Electron userData folder), separate from
`consent.json`. Delete it to reset progress (watched tapes, icon-move
escalation, `???` unlock) without clearing consent.

## In-world README

`README-ARCHIVE.txt` is the in-character version — written as the fictional
archivist who built this to view their own tapes and log what happened. Ship
that one with the app; this `README.md` is the honest developer/behavior doc
and is the one that should stay accurate about what the software actually
does.

## Why the consent dialog is worded the way it is

Per your request, the in-app effects should be a surprise **at the moment
they happen** — but the user should genuinely understand and agree, up
front, to what the software does before installing it. The dialog text in
`main.js` says plainly: it runs in the background, it will trigger sounds
or visuals unannounced, and it asks separately about auto-launch at
startup. That's the line I'd stick to if you reskin the copy — cryptic
*tone* is fine, vague *substance* isn't. A themed rewrite might look like:

> ARCHIVE VIEWER REQUIRES YOUR PERMISSION TO CONTINUE OPERATING AFTER THIS
> WINDOW CLOSES. IT WILL REMAIN ACTIVE IN THE BACKGROUND. IT WILL SPEAK OR
> SHOW ITSELF WITHOUT WARNING. DO YOU CONSENT?

Same substance, spookier voice — swap the strings in `showConsentDialog()`
in `main.js` if you want that tone instead of the plain version currently
there.

## Setup

Requires [Node.js](https://nodejs.org/) installed on the machine you're
developing on.

```bash
cd archive-viewer
npm install
npm start
```

## Background scare effects (sounds / images / flashes)

While the app runs with background consent, one effect fires every
`intervalMinSeconds`–`intervalMaxSeconds` (default **60–180s**, i.e. every
1–3 min). Config is `config/effects.json`.

**Where to put your own content:**
- Sounds → `assets/effects/sounds/` (`.mp3 .wav .ogg .m4a .flac`)
- Images → `assets/effects/images/` (`.png .jpg .jpeg .gif .webp .bmp`)

Drop in as many as you want; the app picks one at random each time. Three
placeholder sounds and three placeholder images ship in those folders — delete
them and add your own. (In a packaged build these are baked in at build time,
so add your finals before running `npm run dist`.)

**Effect types** (edit the `effects` array to enable/disable):
- `image` — a random image appears **full-screen over everything**, with **no
  window frame and no taskbar icon**, click-through, then vanishes after
  `imageMinMs`–`imageMaxMs`.
- `sound` — plays a random sound file, no window at all.
- `black-flash` — the **whole screen goes black** for `blackFlashMs` (default
  500ms).
- `glitch` — the transparent scan-tear overlay.

All of this works in `npm start` (dev) — you do **not** need to package it to
test. The desktop-icon-move effect remains on its own separate escalating
track (Windows only).

Note on background sound: browsers/Electron may block audio playback until the
window has had a user interaction. In practice you'll have clicked something
first; a pure background-launch-then-idle session may stay silent until you
interact once.

## Tape release model (imports)

This is how tapes reach the player during the ARG. The app ships with a
manifest of expected tapes and no footage; the player imports each video as
you release it.

- **The manifest** is `config/expected-tapes.json` — a list of `{ id, label }`.
  `id` is the accepted tape name and the on-disk filename. The five names are
  `cabin`, `pink`, `picture`, `noise`, `mail`. Rename or change the set freely.
- **What imports.** ONLY `.arcv` files. The player clicks **+ IMPORT TAPE**
  (the picker is filtered to `.arcv`) or drops a `.arcv` on the window. The app
  checks: (1) extension is `.arcv`, (2) the `ARCV` magic header is present,
  (3) the name matches a slot (`pink.arcv` → `pink`), (4) that slot isn't
  already logged, (5) the file's content hasn't already been imported under any
  name (SHA-256). Pass all five and it's copied into the **userData**
  `videos/` folder and the slot lights up. The filename shows as `SOURCE`
  metadata.
- **Making tapes to distribute.** Encode each source video into a named
  `.arcv` with `node tools/encode.js <video> <name>` (e.g.
  `node tools/encode.js cabin_raw.mp4 cabin` → `assets/videos/cabin.arcv`).
  Post that `.arcv` wherever the ARG lives (your blog, etc.). Players import it.
- **Why userData, not the app folder.** Once packaged, the app bundle is
  read-only, so imports must land in writable storage. Reads check userData
  first, then any bundled `assets/videos/`.
- **Distribution / cadence is yours, out-of-app.** Post one tape per day; the
  app has no server and can't be clock-cheated. Because names are fixed, a
  player can only fill a slot with the correct tape for it.
- **The gate.** Once every slot is imported **and** watched to the end, the
  hidden `???` unlocks on the next launch (see above).

Reset the whole loop (imported tapes + watched/unlock state) with
`npm run reset -- state`, or wipe everything including consent with
`npm run reset`.

## Adding real videos (manual / dev)

The import button above is the normal path. For quick local testing you can
still pre-encode tapes from the command line:

Videos only play if they're encoded into the custom `.arcv` format first:

```bash
node tools/encode.js /path/to/your-video.mp4 tape_01
```

This creates `assets/videos/tape_01.arcv`. Repeat for each video. The app
picks up every `.arcv` file in `assets/videos/` automatically on launch —
no need to edit any code.

The encoding is XOR obfuscation with a fixed key (see `tools/format.js`) —
enough that the files aren't directly playable by a normal media player or
recognizable as video by extension, which was the ask. It is **not**
real security — don't rely on it to stop a determined person from
recovering the source video; that's not what it's for here.

## Adding sound

Drop an audio file at `assets/sounds/ambient-blip.mp3` (currently
referenced but not included — add your own asset). You can add more sound
files and pick between them randomly in `main.js` / `renderer.js` if you
want variety.

The fake-uninstall sequence (see below) looks for
`assets/sounds/uninstall-scare.mp3` — also not included, add your own.

## The "Uninstall" button

The button in the top-right corner does not uninstall anything. Clicking
it plays a scripted sequence (`renderer.js` for the bar, `main.js` for the
crash) designed to feel ordinary right up until it isn't:

1. About a second passes before anything even appears, like a real
   uninstaller spinning up.
2. A plain, normal-looking system-style progress dialog climbs to 99%
   over several seconds, slowing down near the end like a real installer,
   then stalls for a beat.
3. Nothing visibly glitches. No color change, no "ERROR" text, no popups.
   The bar just keeps quietly climbing past 100% and off the edge of its
   own track, same color and font throughout - which reads as more wrong
   than an obvious effect would.
4. The app hides itself, a short pause passes, and a real native OS
   dialog appears (Electron's own `dialog.showMessageBox`, so it's
   genuinely styled by the operating system) reading "Archive Viewer has
   stopped working," styled like a standard Windows crash report.
5. Once the user clicks through it, the process actually terminates
   (`app.exit(1)`, a hard exit rather than a clean quit) - a real crash
   from the user's point of view. No files are touched and nothing is
   actually uninstalled.

After this plays once, every future launch of the app changes its own
identity: window title, taskbar/dock icon, and tray icon/tooltip switch to
a plain black square named **"I want you to hurt"** (see the
`CORRUPTED_NAME` / `BLACK_ICON_PATH` constants and `isCorrupted()` /
`markCorrupted()` in `main.js`). This persists until the user genuinely
uninstalls the app through their OS's normal uninstall process — this app
never removes or disables that.

### The "death" ending (uninstall after finishing every tape)

If the player has watched every expected tape before pressing UNINSTALL, the
uninstall sequence runs **exactly the same** (confirm → progress bar past
100% → "stopped working" crash → hard exit). The only difference is what's
persisted: instead of the corruption flag, it sets `death`. So on the **next**
launch — and every launch after — the app just opens a **blank pink window**
with no repair flow and no crash; the word `death` appears only in the window
title / taskbar, not on the window itself. Persists until genuinely
uninstalled. State: `death` / `deathAt` in `consent.json`; window is
`renderer/death.html`; icon is `assets/icons/pink-*.png` / `pink.ico`. The
completion check is "all expected tapes watched" — if you'd rather it also
require the `???` tape, that's a one-line change in `get-progress`. (For a
packaged build, point a pink icon at the exe the same way as `black.ico` if
you want the installed icon to change too.)

### What happens on every launch after that

Reopening a corrupted app no longer just crash-loops. Instead
(`renderer/corrupted.html` + the `repair-*` handlers in `main.js`):

1. Blank black window for ~1.5s.
2. Solid blue full-screen flash for ~0.2s (the classic stop-error blue).
3. A real native dialog asks: **"Do you want to try to repair it?"**
   ("Try to repair the program" / "Close"). Close just quits — it'll ask
   again next open.
4. On repair: a harsh downward "freaky" burst plays while the window
   genuinely **freezes** (Not Responding) for ~1.5s, then cuts to black.
5. The app un-corrupts itself and **restarts from the beginning** — the
   consent dialog again, a fresh archive viewer — **but every tape the
   player already imported is kept** (progress like watched/`???`/icon-count
   resets; the `.arcv` files in userData `videos/` stay). Implemented by
   clearing `consent.json` and resetting `state.json` while preserving
   `state.imports`, then `app.relaunch()`.

So the corruption is now a recoverable scare, not a permanent brick.

Two things worth knowing about the current (pre-packaging) state:

- Icon files for this are already generated at
  `assets/icons/black-*.png` and `assets/icons/black.ico`. Once you
  package this with `electron-builder`/`electron-forge`, point its icon
  config at `black.ico` (Windows) so the *installed executable's* icon
  also reflects this if you want the change to go that deep — right now,
  only the running app's window/taskbar/tray icon changes live, since
  rewriting a compiled `.exe`'s embedded icon isn't something that
  happens at runtime.
- `attemptShortcutRename()` in `main.js` will rename a Start Menu shortcut
  named `Archive Viewer.lnk` to `I want you to hurt.lnk`, but only once
  there's a real installed shortcut to rename (a plain `npm start` dev
  run won't have one) — this is a no-op today and just wired up for when
  you package it.

To reset back to the normal identity during testing, delete
`consent.json` from the Electron userData folder (same file mentioned
above for resetting the consent dialog).

## Tray icon

`main.js` looks for `assets/tray-icon.png`. Add a `.png` (ideally 16x16 or
32x32) there for a proper tray icon; without one, tray creation is skipped
gracefully in development.

## Desktop icon movement (Windows only)

One of the randomized background effects, on Windows, is moving a single
random desktop icon to a new spot on the desktop. It's implemented in
`assets/scripts/move-random-icon.ps1`, invoked from `main.js`'s
`moveRandomDesktopIcon()`.

How it works: the Windows desktop is itself just a `SysListView32` control
(the same one Explorer uses), so the script uses the standard public
`user32.dll` messaging API (`LVM_GETITEMCOUNT` / `LVM_SETITEMPOSITION`) to
pick a random icon index and reposition it — the same mechanism legitimate
desktop-layout tools use. It never touches file contents, never renames or
deletes anything, and is fully reversible: right-click the desktop → View
→ "Auto arrange icons" (or just drag things back) restores a normal
layout instantly. This is disclosed explicitly in the consent dialog
before it can ever run. On macOS/Linux this effect is skipped entirely
(the platform check is `process.platform !== 'win32'`).

## Packaging as a real installer

`electron-builder` is now wired up (see the `build` block in `package.json`
and the app icons in `build/`).

**Build the Windows installer (run this on a Windows machine):**

```bash
npm install
npm run dist
```

This produces `dist/Archive Viewer Setup 0.1.0.exe` — a normal installer
(NSIS): the user picks an install location, gets Start Menu / desktop
shortcuts, and can uninstall from Add/Remove Programs. `npm run pack` makes an
unpacked build in `dist/win-unpacked/` without the installer, for quick checks.

Notes:
- **Build Windows on Windows.** Cross-building a Windows `.exe` from macOS/Linux
  needs extra tooling (wine); building on the target OS is simplest and avoids
  code-signing headaches. `npm run dist` on macOS makes a `.dmg`, on Linux an
  `AppImage`.
- The installed **exe icon** is `build/icon.ico` (the normal app icon). The
  runtime window/taskbar icon still swaps to the black "I want you to hurt"
  square or the pink "death" square at those states. If you want the *installed*
  icon to also change at those states, that's a deeper (post-install) trick and
  not wired up.
- Put your final effect sounds/images and any bundled tapes in place **before**
  building — packaged resources are read-only.
- Unsigned installers will show a SmartScreen warning on first run. Code signing
  (an OS cert) removes it; that's a separate step when you're ready to
  distribute widely.

## What I didn't build

I didn't add anything that hides *what* the background behavior is from
the user, or that makes the app monitor/react to what the user is doing in
*other* programs (e.g. watching for browser activity to time the effects).
The scheduler here is just a randomized timer, and everything it does was
disclosed in the consent dialog before it can run at all. If you want help
adjusting the frequency, effect types, or adding more sound/visual
variety, I'm glad to keep building on this.
