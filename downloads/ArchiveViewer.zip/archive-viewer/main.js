// main.js
// Electron main process for "Archive Viewer"
//
// Flow:
// 1. On first launch, show an honest consent dialog explaining exactly what
//    the app will do (run in background, trigger sounds/visual effects
//    unprompted, optionally launch at system startup).
// 2. Consent choice is persisted to disk. Nothing background-related runs
//    until the user has explicitly agreed.
// 3. If the user consents, the main archive window opens and the app can
//    minimize to the system tray and keep running; a randomized scheduler
//    fires ambient "effects" (sound cues / glitch overlays) at intervals,
//    and (Windows only) an escalating desktop-icon-move track.
// 4. If the user does NOT consent to background behavior, the app runs
//    only in the foreground and quits fully when closed, no tray, no
//    scheduler, no startup registration.
//
// TAPE MODEL (import-based ARG release):
//   The archive expects a fixed set of "field tapes" defined in
//   config/expected-tapes.json. Each shows as a locked "NO SIGNAL" slot
//   until the player imports a video file (distributed out-of-app, e.g. via
//   a blog). Importing encodes the file into the custom .arcv format in the
//   userData folder and fills the next empty slot. Once every slot has been
//   imported AND watched to the end, the hidden "???" tape unlocks on the
//   next launch.
//
// Progress state (which tapes imported/watched, icon-move escalation count,
// ??? unlock) lives in state.json, separate from consent.json.

const { app, BrowserWindow, Tray, Menu, ipcMain, dialog, screen, nativeImage } = require('electron');
const path = require('path');
const fs = require('fs');
const crypto = require('crypto');
const { pathToFileURL } = require('url');
const { execFile } = require('child_process');

const CONFIG_DIR = app.getPath('userData');
const CONFIG_PATH = path.join(CONFIG_DIR, 'consent.json');
const STATE_PATH = path.join(CONFIG_DIR, 'state.json');

// Where imported tapes are written. userData is writable even when the app
// is packaged (the app bundle/asar is read-only), so player imports must go
// here. Bundled tapes (if you ship any) live in assets/videos and are read
// as a fallback.
const USER_VIDEOS = path.join(CONFIG_DIR, 'videos');
const BUNDLED_VIDEOS = path.join(__dirname, 'assets', 'videos');
const MANIFEST_PATH = path.join(__dirname, 'config', 'expected-tapes.json');

// Background scare effects: config + the folders you drop sounds/images into.
const EFFECTS_CONFIG_PATH = path.join(__dirname, 'config', 'effects.json');
const EFFECT_IMAGES_DIR = path.join(__dirname, 'assets', 'effects', 'images');
const EFFECT_SOUNDS_DIR = path.join(__dirname, 'assets', 'effects', 'sounds');
const IMAGE_EXTS = ['.png', '.jpg', '.jpeg', '.gif', '.webp', '.bmp'];
const SOUND_EXTS = ['.mp3', '.wav', '.ogg', '.m4a', '.flac'];
const DEFAULT_EFFECTS = {
  intervalMinSeconds: 60,
  intervalMaxSeconds: 180,
  effects: ['image', 'sound', 'black-flash', 'glitch'],
  imageMinMs: 500,
  imageMaxMs: 1400,
  blackFlashMs: 500,
};

// ---------- "Corrupted" identity (post fake-uninstall) ----------
const CORRUPTED_NAME = 'I want you to hurt';
const BLACK_ICON_PATH = path.join(__dirname, 'assets', 'icons', 'black-256.png');

// ---------- "Death" identity (post uninstall AFTER finishing every tape) ----------
// If the player has watched everything and then triggers uninstall, there's
// no crash. Instead the app quietly becomes "death": a pink window and pink
// icon, on this launch and every future one, until genuinely uninstalled.
const DEATH_NAME = 'death';
const PINK_ICON_PATH = path.join(__dirname, 'assets', 'icons', 'pink-256.png');

// Default in-world metadata shown for every tape unless overridden.
const DEFAULT_CAMERA = 'Sony DCR-DVD203 (NTSC)';
const DEFAULT_FORMAT = 'MiniDVD / NTSC 720x480';

const MYSTERY_ID = '???';
// "???" isn't a valid filename, so the hidden tape is imported under the name
// "mystery.arcv" and stored internally as "__mystery.arcv". It can be imported
// at any time; it only provides the ??? tape's content and never affects the
// five field tapes or the death ending.
const MYSTERY_IMPORT_NAME = 'mystery';
const MYSTERY_FILE_ID = '__mystery';

// The app ONLY accepts pre-encoded .arcv tapes (the custom container from
// tools/format.js). Raw video is never imported directly - you encode it
// first and distribute the .arcv. The 4-byte magic header is verified on
// import.
const ARCV_EXT = '.arcv';
const ARCV_MAGIC = 'ARCV';

let mainWindow = null;
let overlayWindows = [];
let tray = null;
let effectsTimer = null;   // ambient sound / glitch overlay track
let iconTimer = null;      // escalating desktop-icon-move track (win32 only)

// Whether ??? was already unlocked when THIS launch started. The reveal is
// deliberately delayed to the next launch after the final tape is watched,
// so we snapshot the flag at startup and only show ??? if it was already
// true then (see whenReady + list-archive-videos).
let mysteryUnlockedAtLaunch = false;

// In a packaged build, bundled files live inside the read-only app.asar
// archive. Node's fs can read those transparently, but EXTERNAL consumers
// can't: powershell.exe can't run a .ps1 inside the asar, and the renderer's
// <img>/<audio> need a real file:// path. Those files are marked asarUnpack
// in package.json, which puts real copies under app.asar.unpacked - this maps
// a bundled path to that real on-disk location. In dev it's a no-op.
function resPath(p) {
  return app.isPackaged ? p.replace(/app\.asar([\\/])/, 'app.asar.unpacked$1') : p;
}

// ---------- Consent persistence ----------

function loadConsent() {
  try {
    return JSON.parse(fs.readFileSync(CONFIG_PATH, 'utf-8'));
  } catch (e) {
    return null;
  }
}

function saveConsent(consent) {
  fs.mkdirSync(CONFIG_DIR, { recursive: true });
  fs.writeFileSync(CONFIG_PATH, JSON.stringify(consent, null, 2));
}

// ---------- Gameplay/progress persistence (state.json) ----------

function loadState() {
  try {
    const parsed = JSON.parse(fs.readFileSync(STATE_PATH, 'utf-8'));
    return {
      watched: Array.isArray(parsed.watched) ? parsed.watched : [],
      imports: (parsed.imports && typeof parsed.imports === 'object') ? parsed.imports : {},
      iconMoveCount: Number.isFinite(parsed.iconMoveCount) ? parsed.iconMoveCount : 0,
      sessionCount: Number.isFinite(parsed.sessionCount) ? parsed.sessionCount : 0,
      mysteryUnlocked: !!parsed.mysteryUnlocked,
    };
  } catch (e) {
    return { watched: [], imports: {}, iconMoveCount: 0, sessionCount: 0, mysteryUnlocked: false };
  }
}

function saveState(state) {
  fs.mkdirSync(CONFIG_DIR, { recursive: true });
  fs.writeFileSync(STATE_PATH, JSON.stringify(state, null, 2));
}

function isCorrupted() {
  const consent = loadConsent();
  return !!(consent && consent.corrupted);
}

function isDeath() {
  const consent = loadConsent();
  return !!(consent && consent.death);
}

function markDeath() {
  const consent = loadConsent() || {};
  consent.death = true;
  consent.deathAt = new Date().toISOString();
  saveConsent(consent);
}

function markCorrupted() {
  const consent = loadConsent() || {};
  consent.corrupted = true;
  consent.corruptedAt = new Date().toISOString();
  saveConsent(consent);
  attemptShortcutRename();
}

function attemptShortcutRename() {
  try {
    if (process.platform !== 'win32') return;
    const startMenuDir = path.join(
      process.env.APPDATA || '',
      'Microsoft', 'Windows', 'Start Menu', 'Programs'
    );
    const oldLnk = path.join(startMenuDir, 'Archive Viewer.lnk');
    const newLnk = path.join(startMenuDir, `${CORRUPTED_NAME}.lnk`);
    if (fs.existsSync(oldLnk)) fs.renameSync(oldLnk, newLnk);
  } catch (e) {
    // Non-fatal - dev environment won't have a real shortcut yet.
  }
}

// ---------- Consent dialog (honest, explicit) ----------

function showConsentDialog() {
  const message =
    'ARCHIVE VIEWER - BEFORE YOU CONTINUE\n\n' +
    'This application is designed to run continuously, including in the ' +
    'background after you close its main window (it will sit in your ' +
    'system tray).\n\n' +
    'While running in the background, it will occasionally play sounds ' +
    'or trigger visual effects on your screen at random, unannounced ' +
    'times, without opening its main window first. On Windows, this may ' +
    'include moving one of your desktop icons to a different spot on the ' +
    'desktop, and it may do this more often the longer you keep using ' +
    'the app.\n\n' +
    'You will also be asked separately whether it should launch ' +
    'automatically when your computer starts.\n\n' +
    'Do you consent to this behavior?';

  const choice = dialog.showMessageBoxSync({
    type: 'warning',
    buttons: ['I consent - continue', 'Do not consent - foreground only', 'Cancel and quit'],
    defaultId: 1,
    cancelId: 2,
    title: 'Archive Viewer - Permission Required',
    message,
    noLink: true,
  });

  if (choice === 2) {
    app.quit();
    return null;
  }

  const backgroundConsent = choice === 0;
  let startupConsent = false;

  if (backgroundConsent) {
    const startupChoice = dialog.showMessageBoxSync({
      type: 'question',
      buttons: ['Yes, launch at startup', 'No, launch manually only'],
      defaultId: 1,
      title: 'Archive Viewer - Startup',
      message:
        'Should Archive Viewer launch automatically every time you log in ' +
        'to this computer?',
      noLink: true,
    });
    startupConsent = startupChoice === 0;
  }

  const consent = {
    backgroundConsent,
    startupConsent,
    decidedAt: new Date().toISOString(),
  };
  saveConsent(consent);
  return consent;
}

// ---------- Startup registration (only if consented) ----------

function applyStartupSetting(enabled) {
  app.setLoginItemSettings({ openAtLogin: enabled, openAsHidden: false });
}

// ---------- Main window ----------

function createMainWindow() {
  const death = isDeath();
  const corrupted = !death && isCorrupted(); // death takes precedence

  const title = death ? DEATH_NAME : corrupted ? CORRUPTED_NAME : 'Archive Viewer';
  const iconFile = death ? PINK_ICON_PATH : corrupted ? BLACK_ICON_PATH : null;
  const icon = iconFile ? nativeImage.createFromPath(resPath(iconFile)) : undefined;
  const bg = death ? '#ff2e88' : corrupted ? '#000000' : '#0a0a0a';
  const page = death ? 'death.html' : corrupted ? 'corrupted.html' : 'index.html';

  // Also nudge the Windows taskbar identity for the state (grouping/label).
  if (process.platform === 'win32') {
    try { app.setAppUserModelId(death ? DEATH_NAME : corrupted ? CORRUPTED_NAME : 'Archive Viewer'); } catch (e) {}
  }

  mainWindow = new BrowserWindow({
    width: 1000,
    height: 700,
    backgroundColor: bg,
    autoHideMenuBar: true,
    title,
    icon,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
    },
  });

  mainWindow.loadFile(path.join(__dirname, 'renderer', page));
  if (death || corrupted) {
    const forced = death ? DEATH_NAME : CORRUPTED_NAME;
    mainWindow.webContents.on('did-finish-load', () => mainWindow.setTitle(forced));
  }

  mainWindow.on('close', (e) => {
    const consent = loadConsent();
    // Use live state (not the captured vars) so a mid-session transition to
    // death/corrupted is respected.
    if (consent && consent.backgroundConsent && !isCorrupted() && !isDeath() && !app.isQuitting) {
      e.preventDefault();
      mainWindow.hide();
    }
  });

  // When the window is closed-to-tray or minimized, tell the renderer to go
  // quiet (pause the tape, suspend the idle hum). The scheduled background
  // scares still fire - those are the point of running in the background - but
  // the continuous sound and any playing tape stop.
  const goQuiet = () => {
    if (mainWindow && !mainWindow.isDestroyed()) mainWindow.webContents.send('app-hidden');
  };
  const goActive = () => {
    if (mainWindow && !mainWindow.isDestroyed()) mainWindow.webContents.send('app-shown');
  };
  mainWindow.on('hide', goQuiet);
  mainWindow.on('minimize', goQuiet);
  mainWindow.on('show', goActive);
  mainWindow.on('restore', goActive);
}

// ---------- Tray ----------

function createTray() {
  const corrupted = isCorrupted();
  const defaultIconPath = path.join(__dirname, 'assets', 'tray-icon.png');
  const iconPath = corrupted
    ? BLACK_ICON_PATH
    : (fs.existsSync(defaultIconPath) ? defaultIconPath : path.join(__dirname, 'assets'));
  try {
    tray = new Tray(iconPath);
  } catch (e) {
    tray = null;
    return;
  }
  const label = corrupted ? CORRUPTED_NAME : 'Open Archive Viewer';
  const menu = Menu.buildFromTemplate([
    { label, click: () => mainWindow.show() },
    { label: 'Quit', click: () => { app.isQuitting = true; app.quit(); } },
  ]);
  tray.setToolTip(corrupted ? CORRUPTED_NAME : 'Archive Viewer (running in background)');
  tray.setContextMenu(menu);
  tray.on('click', () => mainWindow.show());
}

// ---------- Background effects scheduler ----------

function loadEffectsConfig() {
  try {
    const p = JSON.parse(fs.readFileSync(EFFECTS_CONFIG_PATH, 'utf-8'));
    return {
      ...DEFAULT_EFFECTS,
      ...p,
      effects: (Array.isArray(p.effects) && p.effects.length) ? p.effects : DEFAULT_EFFECTS.effects,
    };
  } catch (e) {
    return { ...DEFAULT_EFFECTS };
  }
}

function randomFileFrom(dir, exts) {
  try {
    const files = fs.readdirSync(dir).filter((f) => exts.includes(path.extname(f).toLowerCase()));
    if (!files.length) return null;
    return path.join(dir, files[Math.floor(Math.random() * files.length)]);
  } catch (e) {
    return null;
  }
}

function scheduleNextAmbientEffect() {
  const cfg = loadEffectsConfig();
  const minMs = Math.max(5, cfg.intervalMinSeconds) * 1000;
  const maxMs = Math.max(minMs, cfg.intervalMaxSeconds * 1000);
  const delay = minMs + Math.random() * (maxMs - minMs);
  effectsTimer = setTimeout(fireAmbientEffect, delay);
}

function fireAmbientEffect() {
  const cfg = loadEffectsConfig();
  const pool = cfg.effects.slice();
  const pick = pool[Math.floor(Math.random() * pool.length)];
  try {
    if (pick === 'sound') playRandomSound();
    else if (pick === 'image') spawnImageOverlay(cfg);
    else if (pick === 'black-flash') spawnBlackFlash(cfg);
    else spawnGlitchOverlay();
  } catch (e) {
    // Never let a single effect kill the loop.
  }
  scheduleNextAmbientEffect();
}

// Play a random sound file through the (possibly hidden) main window's
// renderer. No window is shown for this - just audio.
function playRandomSound() {
  const f = randomFileFrom(EFFECT_SOUNDS_DIR, SOUND_EXTS);
  if (!f || !mainWindow) return;
  mainWindow.webContents.send('play-sound-file', pathToFileURL(resPath(f)).href);
}

// A random image, full-screen, over everything - frameless, transparent,
// click-through, and NOT in the taskbar - then gone after a beat.
function spawnImageOverlay(cfg) {
  const f = randomFileFrom(EFFECT_IMAGES_DIR, IMAGE_EXTS);
  if (!f) return;
  const { x, y, width, height } = screen.getPrimaryDisplay().bounds;

  const overlay = new BrowserWindow({
    x, y, width, height,
    frame: false, transparent: true, alwaysOnTop: true, skipTaskbar: true,
    focusable: false, resizable: false, movable: false,
    minimizable: false, maximizable: false, hasShadow: false,
    enableLargerThanScreen: true,
    webPreferences: { contextIsolation: true },
  });
  overlay.setAlwaysOnTop(true, 'screen-saver');
  overlay.setIgnoreMouseEvents(true);
  try { overlay.setVisibleOnAllWorkspaces(true); } catch (e) {}
  overlay.loadFile(path.join(__dirname, 'renderer', 'image-overlay.html'),
    { query: { src: pathToFileURL(resPath(f)).href } });
  overlayWindows.push(overlay);

  const life = cfg.imageMinMs + Math.random() * (cfg.imageMaxMs - cfg.imageMinMs);
  setTimeout(() => {
    if (!overlay.isDestroyed()) overlay.close();
    overlayWindows = overlayWindows.filter((w) => w !== overlay);
  }, life);
}

// The whole screen goes black for a beat.
function spawnBlackFlash(cfg) {
  const { x, y, width, height } = screen.getPrimaryDisplay().bounds;

  const overlay = new BrowserWindow({
    x, y, width, height,
    frame: false, alwaysOnTop: true, skipTaskbar: true, focusable: false,
    backgroundColor: '#000000', show: false, resizable: false,
    hasShadow: false, enableLargerThanScreen: true,
    webPreferences: { contextIsolation: true },
  });
  overlay.setAlwaysOnTop(true, 'screen-saver');
  overlay.setIgnoreMouseEvents(true);
  overlay.loadFile(path.join(__dirname, 'renderer', 'black-overlay.html'));
  overlay.once('ready-to-show', () => { if (!overlay.isDestroyed()) overlay.show(); });
  overlayWindows.push(overlay);

  setTimeout(() => {
    if (!overlay.isDestroyed()) overlay.close();
    overlayWindows = overlayWindows.filter((w) => w !== overlay);
  }, cfg.blackFlashMs);
}

// --- Escalating desktop-icon track ---

const ICON_FIRST_MIN_MS = 8 * 60 * 1000;
const ICON_FIRST_MAX_MS = 14 * 60 * 1000;
const ICON_BASE_MS = 11 * 60 * 1000;
const ICON_STEP_MS = 55 * 1000;
const ICON_FLOOR_MS = 40 * 1000;
const ICON_JITTER_MS = 25 * 1000;

function nextIconDelay(count) {
  if (count <= 0) {
    return ICON_FIRST_MIN_MS + Math.random() * (ICON_FIRST_MAX_MS - ICON_FIRST_MIN_MS);
  }
  const base = Math.max(ICON_FLOOR_MS, ICON_BASE_MS - count * ICON_STEP_MS);
  const jitter = (Math.random() * 2 - 1) * ICON_JITTER_MS;
  return Math.max(ICON_FLOOR_MS, base + jitter);
}

function scheduleNextIconMove() {
  if (process.platform !== 'win32') return;
  const state = loadState();
  iconTimer = setTimeout(fireIconMove, nextIconDelay(state.iconMoveCount));
}

function fireIconMove() {
  moveRandomDesktopIcon();
  const state = loadState();
  state.iconMoveCount += 1;
  saveState(state);
  scheduleNextIconMove();
}

function moveRandomDesktopIcon() {
  if (process.platform !== 'win32') return;
  const scriptPath = resPath(path.join(__dirname, 'assets', 'scripts', 'move-random-icon.ps1'));
  execFile(
    'powershell.exe',
    ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', scriptPath],
    () => {}
  );
}

function spawnGlitchOverlay() {
  const display = screen.getPrimaryDisplay();
  const { width, height } = display.workAreaSize;

  const overlay = new BrowserWindow({
    width, height, x: 0, y: 0,
    frame: false, transparent: true, alwaysOnTop: true,
    skipTaskbar: true, focusable: false,
    webPreferences: { contextIsolation: true },
  });
  overlay.setIgnoreMouseEvents(true);
  overlay.loadFile(path.join(__dirname, 'renderer', 'glitch-overlay.html'));
  overlayWindows.push(overlay);

  const life = 400 + Math.random() * 900;
  setTimeout(() => {
    if (!overlay.isDestroyed()) overlay.close();
    overlayWindows = overlayWindows.filter((w) => w !== overlay);
  }, life);
}

// ---------- Manifest + tape file resolution ----------

const DEFAULT_MANIFEST = [
  { id: 'cabin',   label: 'CABIN' },
  { id: 'pink',    label: 'PINK' },
  { id: 'picture', label: 'PICTURE' },
  { id: 'noise',   label: 'NOISE' },
  { id: 'mail',    label: 'MAIL' },
];

function loadManifest() {
  try {
    const parsed = JSON.parse(fs.readFileSync(MANIFEST_PATH, 'utf-8'));
    const tapes = Array.isArray(parsed) ? parsed : parsed.tapes;
    if (Array.isArray(tapes) && tapes.length) {
      return tapes
        .filter((t) => t && t.id)
        .map((t) => ({ id: String(t.id), label: t.label || String(t.id) }));
    }
  } catch (e) {
    // fall through to default
  }
  return DEFAULT_MANIFEST.slice();
}

function videosDirs() {
  return [USER_VIDEOS, BUNDLED_VIDEOS];
}

// Resolve a tape id to an on-disk .arcv path, preferring the writable
// userData store over any bundled copy. Returns null if not present.
function findTapeFile(id) {
  for (const dir of videosDirs()) {
    const p = path.join(dir, `${id}.arcv`);
    if (fs.existsSync(p)) return p;
  }
  return null;
}

// The hidden "???" payload: the first "_*.arcv" found in either dir.
function findHiddenFile() {
  for (const dir of videosDirs()) {
    try {
      const hidden = fs.readdirSync(dir).filter((f) => f.endsWith('.arcv') && f.startsWith('_'));
      if (hidden.length) return path.join(dir, hidden[0]);
    } catch (e) { /* dir may not exist */ }
  }
  return null;
}

// Any .arcv not tied to a manifest slot and not hidden - lets the dev
// encode.js workflow keep working for ad-hoc test tapes.
function looseExtraTapes(manifestIds) {
  const seen = new Set();
  const extras = [];
  for (const dir of videosDirs()) {
    let files = [];
    try { files = fs.readdirSync(dir); } catch (e) { continue; }
    for (const f of files) {
      if (!f.endsWith('.arcv') || f.startsWith('_')) continue;
      const id = f;
      const base = path.basename(f, '.arcv');
      if (manifestIds.has(base)) continue;   // belongs to a slot
      if (seen.has(id)) continue;            // userData copy already won
      seen.add(id);
      extras.push(id);
    }
  }
  return extras;
}

// ---------- Metadata helpers ----------

function hashString(str) {
  let h = 2166136261;
  for (let i = 0; i < str.length; i++) {
    h ^= str.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}

function pad2(n) { return String(n).padStart(2, '0'); }

function lastOpenedFor(id) {
  const h = hashString(id);
  const month = (h % 12) + 1;
  const day = ((h >>> 4) % 28) + 1;
  const hour = (h >>> 9) % 24;
  const minute = (h >>> 14) % 60;
  return `2018-${pad2(month)}-${pad2(day)} ${pad2(hour)}:${pad2(minute)}`;
}

function mimeFor(ext) {
  switch ((ext || '').toLowerCase()) {
    case '.webm': return 'video/webm';
    case '.ogg':
    case '.ogv': return 'video/ogg';
    default: return 'video/mp4';
  }
}

// ---------- Progress evaluation ----------

// True once every manifest slot has been imported AND watched to the end.
function allSlotsCleared(manifest, state) {
  return manifest.length > 0 && manifest.every(
    (t) => !!findTapeFile(t.id) && state.watched.includes(t.id)
  );
}

// Recompute + persist the ??? unlock. Called after imports and after watches.
// Note: this only sets the persisted flag; the visible reveal waits for the
// next launch (mysteryUnlockedAtLaunch), preserving the "close and reopen"
// beat.
function refreshMysteryUnlock() {
  const state = loadState();
  if (!state.mysteryUnlocked && allSlotsCleared(loadManifest(), state)) {
    state.mysteryUnlocked = true;
    saveState(state);
  }
}

// ---------- IPC: video listing / decoding ----------

const { encodeToArcv, decodeArcvToBuffer } = require('./tools/format');

ipcMain.handle('list-archive-videos', async () => {
  // Only the userData store is writable; the bundled dir lives in the
  // read-only asar when packaged, so never try to create it.
  try { fs.mkdirSync(USER_VIDEOS, { recursive: true }); } catch (e) {}

  const manifest = loadManifest();
  const manifestIds = new Set(manifest.map((t) => t.id));
  const state = loadState();

  // Ordered slots: imported (playable, with metadata) or locked (NO SIGNAL).
  const slots = manifest.map((t) => {
    const imported = !!findTapeFile(t.id);
    const imp = state.imports[t.id];
    return {
      id: t.id,
      label: t.label,
      locked: !imported,
      camera: imported ? DEFAULT_CAMERA : '—',
      format: imported ? DEFAULT_FORMAT : '—',
      lastOpened: imported ? lastOpenedFor(t.id) : '—',
      source: (imp && imp.originalName) || null,
      mystery: false,
    };
  });

  // Ad-hoc extra tapes (dev encode.js workflow), always playable.
  const extras = looseExtraTapes(manifestIds).map((id) => ({
    id,
    label: path.basename(id, '.arcv').replace(/_/g, ' '),
    locked: false,
    camera: DEFAULT_CAMERA,
    format: DEFAULT_FORMAT,
    lastOpened: lastOpenedFor(id),
    source: null,
    mystery: false,
  }));

  refreshMysteryUnlock();

  const list = [...slots, ...extras];
  if (mysteryUnlockedAtLaunch) {
    list.push({
      id: MYSTERY_ID,
      label: '???',
      locked: false,
      camera: 'UNKNOWN',
      format: 'SIGNAL / ????',
      lastOpened: '——',
      source: null,
      mystery: true,
    });
  }
  return list;
});

ipcMain.handle('load-archive-video', async (_evt, id) => {
  if (id === MYSTERY_ID) {
    // Prefer an imported mystery tape (mystery.arcv -> __mystery.arcv); fall
    // back to any bundled "_*.arcv" hidden file; otherwise the renderer shows
    // its procedural lost-signal screen.
    const imported = path.join(USER_VIDEOS, `${MYSTERY_FILE_ID}.arcv`);
    const src = fs.existsSync(imported) ? imported : findHiddenFile();
    if (!src) return null;
    const buf = decodeArcvToBuffer(src);
    return `data:${mimeFor(path.extname(src))};base64,${buf.toString('base64')}`;
  }

  const filePath = findTapeFile(id) || path.join(USER_VIDEOS, id); // extras pass full "name.arcv"
  const resolved = fs.existsSync(filePath)
    ? filePath
    : path.join(BUNDLED_VIDEOS, id);
  const buf = decodeArcvToBuffer(resolved);

  const state = loadState();
  const ext = (state.imports[id] && state.imports[id].ext) || '.mp4';
  return `data:${mimeFor(ext)};base64,${buf.toString('base64')}`;
});

// ---------- IPC: import a tape into the next empty slot ----------

ipcMain.handle('import-tape', async (_evt, providedPath) => {
  // Surface every rejection as a visible dialog so the player (and you) can
  // see exactly why a tape didn't take.
  const fail = (msg) => {
    try {
      dialog.showMessageBox(mainWindow, {
        type: 'warning', buttons: ['OK'], noLink: true,
        title: 'Archive Viewer', message: 'Tape not imported', detail: msg,
      });
    } catch (e) {}
    return { ok: false, error: msg };
  };

  let sourcePath = providedPath;

  if (!sourcePath) {
    const res = await dialog.showOpenDialog(mainWindow, {
      title: 'Import Tape',
      properties: ['openFile'],
      filters: [{ name: 'Archive Tape', extensions: ['arcv'] }],
    });
    if (res.canceled || !res.filePaths.length) return { ok: false, canceled: true };
    sourcePath = res.filePaths[0];
  }

  // 1) Must be a .arcv file.
  if (path.extname(sourcePath).toLowerCase() !== ARCV_EXT) {
    return fail('Only .arcv tapes can be imported — that file is a different format.');
  }
  if (!fs.existsSync(sourcePath)) {
    return fail('That file could not be found.');
  }

  // 2) Verify the ARCV magic header (not just the extension).
  let bytes;
  try {
    bytes = fs.readFileSync(sourcePath);
  } catch (e) {
    return fail('That file could not be read.');
  }
  if (bytes.length < 5 || bytes.subarray(0, 4).toString() !== ARCV_MAGIC) {
    return fail('That .arcv tape is corrupt or invalid.');
  }

  // 3) The name (minus .arcv) must match one of the accepted tape names.
  const baseName = path.basename(sourcePath, ARCV_EXT).toLowerCase();
  const manifest = loadManifest();
  let targetSlot = manifest.find((t) => t.id.toLowerCase() === baseName);
  // Special case: the hidden ??? tape, imported as "mystery.arcv". It fills a
  // separate internal slot and does NOT count toward the five field tapes or
  // the death ending. It can be imported at any time, before or after the ???
  // slot is unlocked.
  if (!targetSlot && baseName === MYSTERY_IMPORT_NAME) {
    targetSlot = { id: MYSTERY_FILE_ID, label: '???' };
  }
  if (!targetSlot) {
    const names = manifest.map((t) => t.id).join(', ');
    return fail(`Unrecognized tape name. Accepted tapes: ${names} (or "${MYSTERY_IMPORT_NAME}" for the ??? tape).`);
  }

  const state = loadState();

  // 4) That slot can't already be logged (a real file present for it).
  if (findTapeFile(targetSlot.id)) {
    return fail(`“${targetSlot.label}” is already logged.`);
  }

  // 5) The same content can't be imported twice — but only count a match if
  //    that slot's file still exists on disk. (A stale hash left over after
  //    the file was deleted must NOT block re-importing.)
  const hash = crypto.createHash('sha256').update(bytes).digest('hex');
  const dupe = Object.entries(state.imports)
    .find(([slotId, imp]) => imp && imp.hash === hash && findTapeFile(slotId));
  if (dupe) {
    return fail('This exact tape has already been logged.');
  }

  // 6) Copy the .arcv into the writable store, filling its named slot.
  try {
    fs.mkdirSync(USER_VIDEOS, { recursive: true });
    fs.writeFileSync(path.join(USER_VIDEOS, `${targetSlot.id}.arcv`), bytes);

    state.imports[targetSlot.id] = {
      originalName: path.basename(sourcePath),
      hash,
      importedAt: new Date().toISOString(),
    };
    saveState(state);

    return { ok: true, slotId: targetSlot.id, label: targetSlot.label };
  } catch (e) {
    return fail(`Import failed: ${e.message}`);
  }
});

// Renderer reports a tape watched (fired when playback reaches the end).
ipcMain.handle('mark-tape-watched', async (_evt, id) => {
  if (!id || id === MYSTERY_ID) return;
  const state = loadState();
  if (!state.watched.includes(id)) {
    state.watched.push(id);
    saveState(state);
  }
  refreshMysteryUnlock();
});

// ---------- IPC: uninstall confirmation ----------

// Renderer asks whether the player has finished everything, to decide which
// uninstall outcome to run (death ending vs. the crash/corruption).
ipcMain.handle('get-progress', async () => {
  const state = loadState();
  const completed = state.mysteryUnlocked || allSlotsCleared(loadManifest(), state);
  return { completed };
});

ipcMain.handle('confirm-uninstall', async () => {
  const { response } = await dialog.showMessageBox(mainWindow, {
    type: 'warning',
    buttons: ['Yes', 'No'],
    defaultId: 1,
    cancelId: 1,
    title: 'Archive Viewer',
    message: 'Are you sure you want to uninstall Archive Viewer?',
    detail: 'This will remove Archive Viewer from your computer.',
    noLink: true,
  });
  return response === 0;
});

// ---------- IPC: fake uninstall sequence ----------

ipcMain.handle('fake-uninstall-close', async (_evt, death) => {
  if (mainWindow) mainWindow.hide();
  await new Promise((resolve) => setTimeout(resolve, 1200));

  await dialog.showMessageBox({
    type: 'error',
    title: 'Archive Viewer has stopped working',
    message: 'Archive Viewer has stopped working',
    detail:
      'A problem caused the program to stop working correctly. ' +
      'Windows will close the program and notify you if a solution ' +
      'is available.',
    buttons: ['Close the program'],
    defaultId: 0,
    noLink: true,
  });

  // Same sequence for both endings; only the persisted end-state differs.
  // death  -> next launch opens a blank pink "death" window (no repair).
  // else   -> next launch runs the corrupted black/blue/repair flow.
  if (death) markDeath();
  else markCorrupted();

  app.isQuitting = true;
  app.exit(1);
});

// ---------- IPC: repair flow (corrupted relaunch) ----------
// After the fake-uninstall corruption, reopening no longer just crash-loops.
// corrupted.html plays black -> blue -> asks to repair -> freaky noise/freeze
// -> black, then calls repair-complete, which un-corrupts the app and restarts
// it fresh FROM THE BEGINNING (consent dialog again), while KEEPING every tape
// the player already imported.

ipcMain.handle('repair-prompt', async () => {
  const { response } = await dialog.showMessageBox(mainWindow, {
    type: 'error',
    buttons: ['Try to repair the program', 'Close'],
    defaultId: 0,
    cancelId: 1,
    title: 'Archive Viewer',
    message: 'Archive Viewer has stopped working',
    detail: 'The program appears to be damaged. Do you want to try to repair it?',
    noLink: true,
  });
  return response === 0;
});

ipcMain.handle('repair-complete', async () => {
  // Reset progress but KEEP imported tapes and their metadata.
  const state = loadState();
  saveState({
    watched: [],
    imports: state.imports || {},
    iconMoveCount: 0,
    sessionCount: 0,
    mysteryUnlocked: false,
  });

  // Clearing consent.json removes the corrupted flag (and re-triggers the
  // consent dialog) so it truly starts over. Imported .arcv files in
  // userData/videos are untouched.
  try { fs.unlinkSync(CONFIG_PATH); } catch (e) { /* already gone */ }

  app.isQuitting = true;
  app.relaunch();
  app.exit(0);
});

// ---------- App lifecycle ----------

app.whenReady().then(() => {
  if (isDeath()) {
    // The finished ending. A pink "death" window, every launch, no crash.
    app.setName(DEATH_NAME);
    createMainWindow();
    return;
  }

  if (isCorrupted()) {
    // Tear down any login-launch registration so the crash loop can't ambush
    // the user at every boot; the loop still plays when they open it.
    applyStartupSetting(false);
    app.setName(CORRUPTED_NAME);
    createMainWindow();
    return;
  }

  let consent = loadConsent();
  if (!consent) {
    consent = showConsentDialog();
    if (!consent) return;
  }

  const state = loadState();
  mysteryUnlockedAtLaunch = state.mysteryUnlocked; // snapshot before this session's watches
  state.sessionCount += 1;
  saveState(state);

  applyStartupSetting(consent.backgroundConsent && consent.startupConsent);
  createMainWindow();

  if (consent.backgroundConsent) {
    createTray();
    scheduleNextAmbientEffect();
    scheduleNextIconMove();
  }

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createMainWindow();
    else mainWindow.show();
  });
});

app.on('window-all-closed', () => {
  const consent = loadConsent();
  if (isCorrupted() || !consent || !consent.backgroundConsent) {
    app.quit();
  }
});

app.on('before-quit', () => {
  app.isQuitting = true;
  if (effectsTimer) clearTimeout(effectsTimer);
  if (iconTimer) clearTimeout(iconTimer);
});
