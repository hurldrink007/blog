const { contextBridge, ipcRenderer, webUtils } = require('electron');

contextBridge.exposeInMainWorld('archive', {
  listVideos: () => ipcRenderer.invoke('list-archive-videos'),
  loadVideo: (id) => ipcRenderer.invoke('load-archive-video', id),
  importTape: (sourcePath) => ipcRenderer.invoke('import-tape', sourcePath),
  markWatched: (id) => ipcRenderer.invoke('mark-tape-watched', id),
  confirmUninstall: () => ipcRenderer.invoke('confirm-uninstall'),
  getProgress: () => ipcRenderer.invoke('get-progress'),
  onPlaySound: (callback) => ipcRenderer.on('play-sound-file', (_e, url) => callback(url)),
  onAppHidden: (callback) => ipcRenderer.on('app-hidden', () => callback()),
  onAppShown: (callback) => ipcRenderer.on('app-shown', () => callback()),
  triggerFakeUninstallClose: (death) => ipcRenderer.invoke('fake-uninstall-close', death),
  repairPrompt: () => ipcRenderer.invoke('repair-prompt'),
  repairComplete: () => ipcRenderer.invoke('repair-complete'),
  // Resolve a dropped File to its absolute path (Electron 30+ way; File.path
  // is no longer populated under contextIsolation).
  getDroppedPath: (file) => {
    try { return webUtils.getPathForFile(file); } catch (e) { return null; }
  },
});
