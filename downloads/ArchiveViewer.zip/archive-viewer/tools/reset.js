#!/usr/bin/env node
// Usage: npm run reset            (clears everything: consent + progress)
//        npm run reset -- state   (clears only progress: watched/icon/???)
//        npm run reset -- consent (clears only consent + corrupted flag)
//
// Wipes the app's saved files from Electron's userData folder so you can
// re-test from a clean slate - in particular, clears the "corrupted" flag
// that makes the app do the black/flash/crash loop after a fake uninstall.
//
// This resolves the SAME userData path Electron uses, so it targets the
// real files main.js reads/writes. It only removes this app's own
// consent.json / state.json - nothing else.

const fs = require('fs');
const path = require('path');
const os = require('os');

const APP_DIR_NAME = require('../package.json').name; // "archive-viewer"

function userDataDir() {
  const home = os.homedir();
  switch (process.platform) {
    case 'win32':
      return path.join(process.env.APPDATA || path.join(home, 'AppData', 'Roaming'), APP_DIR_NAME);
    case 'darwin':
      return path.join(home, 'Library', 'Application Support', APP_DIR_NAME);
    default:
      return path.join(process.env.XDG_CONFIG_HOME || path.join(home, '.config'), APP_DIR_NAME);
  }
}

const which = (process.argv[2] || 'all').toLowerCase();
const targets = [];
if (which === 'all' || which === 'consent') targets.push('consent.json');
if (which === 'all' || which === 'state') targets.push('state.json');
// Imported tapes are progress too, so clear them with state/all - otherwise
// slots would still read as imported (the .arcv files) with no source data.
const clearVideos = (which === 'all' || which === 'state');

const dir = userDataDir();
let removed = 0;
for (const name of targets) {
  const p = path.join(dir, name);
  try {
    fs.unlinkSync(p);
    console.log(`removed  ${p}`);
    removed++;
  } catch (e) {
    if (e.code === 'ENOENT') console.log(`(absent) ${p}`);
    else console.warn(`failed   ${p}: ${e.message}`);
  }
}

if (clearVideos) {
  const vids = path.join(dir, 'videos');
  try {
    const files = fs.readdirSync(vids).filter((f) => f.endsWith('.arcv'));
    for (const f of files) fs.unlinkSync(path.join(vids, f));
    console.log(`removed  ${files.length} imported tape(s) in ${vids}`);
    removed += files.length;
  } catch (e) {
    if (e.code === 'ENOENT') console.log(`(absent) ${vids}`);
    else console.warn(`failed   ${vids}: ${e.message}`);
  }
}

console.log(removed ? `\nReset done - next launch starts fresh.` : `\nNothing to remove (already clean).`);
