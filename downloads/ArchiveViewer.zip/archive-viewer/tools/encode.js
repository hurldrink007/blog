#!/usr/bin/env node
// Usage: node tools/encode.js /path/to/video.mp4 [output_name]
//
// Encodes a real video file into the app's custom .arcv format and drops
// it into assets/videos/, where the app will pick it up automatically.

const path = require('path');
const fs = require('fs');
const { encodeToArcv } = require('./format');

const [, , inputPath, outputName] = process.argv;

if (!inputPath) {
  console.error('Usage: node tools/encode.js <input.mp4> [output_name]');
  process.exit(1);
}

if (!fs.existsSync(inputPath)) {
  console.error(`File not found: ${inputPath}`);
  process.exit(1);
}

const videosDir = path.join(__dirname, '..', 'assets', 'videos');
fs.mkdirSync(videosDir, { recursive: true });

const base = outputName || path.basename(inputPath, path.extname(inputPath));
const outPath = path.join(videosDir, `${base}.arcv`);

encodeToArcv(inputPath, outPath);
console.log(`Encoded: ${inputPath} -> ${outPath}`);
