// tools/format.js
//
// A minimal custom container format ".arcv" so source video files aren't
// directly playable outside this app. This is obfuscation, not real
// cryptographic security - fine for an ARG prop, not meant to stop a
// determined reverse-engineer.
//
// Layout: [4 bytes magic "ARCV"] [1 byte format version] [remaining bytes:
// XOR-obfuscated original video bytes]

const fs = require('fs');

const MAGIC = Buffer.from('ARCV');
const VERSION = 1;
// Change this key for your project; keeping it out of source control in a
// real build is easy (env var / build-time injection) but not required for
// an ARG prop.
const KEY = Buffer.from('archive-viewer-obfuscation-key');

function xor(buffer, key) {
  const out = Buffer.alloc(buffer.length);
  for (let i = 0; i < buffer.length; i++) {
    out[i] = buffer[i] ^ key[i % key.length];
  }
  return out;
}

function encodeToArcv(inputPath, outputPath) {
  const raw = fs.readFileSync(inputPath);
  const obfuscated = xor(raw, KEY);
  const header = Buffer.concat([MAGIC, Buffer.from([VERSION])]);
  fs.writeFileSync(outputPath, Buffer.concat([header, obfuscated]));
}

function decodeArcvToBuffer(arcvPath) {
  const data = fs.readFileSync(arcvPath);
  const magic = data.subarray(0, 4);
  if (!magic.equals(MAGIC)) {
    throw new Error(`Not a valid .arcv file: ${arcvPath}`);
  }
  const body = data.subarray(5); // skip magic + version byte
  return xor(body, KEY);
}

module.exports = { encodeToArcv, decodeArcvToBuffer };
